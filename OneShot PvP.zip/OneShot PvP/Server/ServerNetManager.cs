﻿using Hkmp.Api.Server;
using Hkmp.Api.Server.Networking;
using Hkmp.Networking.Packet;
using Hkmp.Networking.Packet.Data;

using OneShotPvP.Networking;
using OneShotPvP.Networking.Packets;

namespace OneShotPvP.Server
{
    internal sealed class ServerNetManager
    {
        private readonly IServerAddonNetworkSender<OneShotClientPacketId>
            _netSender;

        private readonly ServerManaManager _manaManager;

        public ServerNetManager(
            OneShotServerAddon addon,
            IServerApi serverApi,
            ServerManaManager manaManager)
        {
            _manaManager = manaManager;

            _netSender =
                serverApi.NetServer.GetNetworkSender<OneShotClientPacketId>(
                    addon
                );

            var netReceiver =
                serverApi.NetServer.GetNetworkReceiver<OneShotServerPacketId>(
                    addon,
                    InstantiatePacket
                );

            netReceiver.RegisterPacketHandler(
                OneShotServerPacketId.ResetMana,
                OnResetMana
            );

            netReceiver.RegisterPacketHandler<DeathReportPacket>(
                OneShotServerPacketId.DeathReport,
                OnDeathReport
            );
        }

        private static IPacketData InstantiatePacket(
            OneShotServerPacketId packetId)
        {
            switch (packetId)
            {
                case OneShotServerPacketId.ResetMana:
                    return new ReliableEmptyData();

                case OneShotServerPacketId.DeathReport:
                    return new DeathReportPacket();
            }

            return null;
        }

        private void OnResetMana(
            ushort playerId)
        {
            _manaManager.ResetPlayer(playerId);

            SendMana(playerId);
        }

        private void OnDeathReport(
            ushort playerId,
            DeathReportPacket packet)
        {
            ushort victimId = playerId;
            ushort killerId = packet.KillerId;

            if (killerId == victimId)
            {
                return;
            }

            int reward = _manaManager.GiveKillReward(
                killerId,
                victimId
            );

            SendMana(killerId);
            SendMana(victimId);
        }

        private void SendMana(ushort playerId)
        {
            int mana = _manaManager.GetMana(playerId);

            _netSender.SendSingleData(
                OneShotClientPacketId.ManaUpdate,
                new ManaUpdatePacket(mana),
                playerId
            );
        }

        public void SendInitialMana(ushort playerId)
        {
            SendMana(playerId);
        }
    }
}