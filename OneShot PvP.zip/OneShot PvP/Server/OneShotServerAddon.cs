﻿using Hkmp.Api.Server;

namespace OneShotPvP.Server
{
    internal sealed class OneShotServerAddon : ServerAddon
    {
        private ServerManaManager _manaManager;
        private ServerNetManager _network;

        protected override string Name
        {
            get { return OneShotConstants.Name; }
        }

        protected override string Version
        {
            get { return OneShotConstants.Version; }
        }

        public override bool NeedsNetwork
        {
            get { return true; }
        }

        public override void Initialize(IServerApi serverApi)
        {
            _manaManager = new ServerManaManager();

            _network = new ServerNetManager(
                this,
                serverApi,
                _manaManager
            );

            serverApi.ServerManager.PlayerConnectEvent +=
                OnPlayerConnect;

            serverApi.ServerManager.PlayerDisconnectEvent +=
                OnPlayerDisconnect;
        }

        private void OnPlayerConnect(
            IServerPlayer player)
        {
            _manaManager.AddPlayer(player.Id);

            _network.SendInitialMana(player.Id);
        }

        private void OnPlayerDisconnect(
            IServerPlayer player)
        {
            _manaManager.RemovePlayer(player.Id);
        }
    }
}