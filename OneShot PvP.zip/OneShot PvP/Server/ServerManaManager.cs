﻿using System;
using System.Collections.Generic;

namespace OneShotPvP.Server
{
    internal sealed class ServerManaManager
    {
        private readonly Dictionary<ushort, int> _mana =
            new Dictionary<ushort, int>();

        public int GetMana(ushort playerId)
        {
            int mana;

            if (_mana.TryGetValue(playerId, out mana))
            {
                return mana;
            }

            return 0;
        }

        public void AddPlayer(ushort playerId)
        {
            _mana[playerId] = OneShotConstants.CastMana;
        }

        public void RemovePlayer(ushort playerId)
        {
            _mana.Remove(playerId);
        }

        public void ResetPlayer(ushort playerId)
        {
            _mana[playerId] = 0;
        }

        public int GiveKillReward(
            ushort killerId,
            ushort victimId)
        {
            int victimMana = GetMana(victimId);

            int reward = Math.Max(
                OneShotConstants.CastMana,
                victimMana
            );

            _mana[victimId] = 0;

            int killerMana = GetMana(killerId);

            _mana[killerId] =
                killerMana + reward;

            return reward;
        }

        public void SetMana(
            ushort playerId,
            int mana)
        {
            if (mana < 0)
            {
                mana = 0;
            }

            _mana[playerId] = mana;
        }

        public void Clear()
        {
            _mana.Clear();
        }
    }
}