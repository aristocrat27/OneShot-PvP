﻿namespace OneShotPvP.Networking
{
    internal enum OneShotClientPacketId : byte
    {
        ManaUpdate = 0
    }
}