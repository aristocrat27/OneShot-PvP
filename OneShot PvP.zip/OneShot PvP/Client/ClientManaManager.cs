﻿namespace OneShotPvP.Client
{
    internal static class ClientManaManager
    {
        private static int _serverMana;

        public static int Mana
        {
            get { return _serverMana; }
        }

        public static void SetMana(int mana)
        {
            if (mana < 0)
            {
                mana = 0;
            }

            _serverMana = mana;

            ApplyToPlayer();
        }

        private static void ApplyToPlayer()
        {
            if (PlayerData.instance == null)
            {
                return;
            }

            PlayerData.instance.MPCharge = _serverMana;
            PlayerData.instance.MPReserve = 0;
        }

        public static void Clear()
        {
            _serverMana = 0;

            if (PlayerData.instance != null)
            {
                PlayerData.instance.MPCharge = 0;
                PlayerData.instance.MPReserve = 0;
            }
        }
    }
}