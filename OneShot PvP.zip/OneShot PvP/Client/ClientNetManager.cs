﻿using Hkmp.Api.Client;
using Hkmp.Api.Client.Networking;
using Hkmp.Networking.Packet;
using Hkmp.Networking.Packet.Data;

using OneShotPvP.Networking;
using OneShotPvP.Networking.Packets;

namespace OneShotPvP.Client
{
    internal sealed class ClientNetManager
    {
        private readonly IClientAddonNetworkSender<OneShotServerPacketId> _netSender;

        public ClientNetManager(
            OneShotClientAddon addon,
            INetClient netClient)
        {
            _netSender =
                netClient.GetNetworkSender<OneShotServerPacketId>(
                    addon
                );

            var netReceiver =
                netClient.GetNetworkReceiver<OneShotClientPacketId>(
                    addon,
                    InstantiatePacket
                );

            netReceiver.RegisterPacketHandler<ManaUpdatePacket>(
                OneShotClientPacketId.ManaUpdate,
                OnManaUpdate
            );
        }

        private static IPacketData InstantiatePacket(
            OneShotClientPacketId packetId)
        {
            switch (packetId)
            {
                case OneShotClientPacketId.ManaUpdate:
                    return new ManaUpdatePacket();
            }

            return null;
        }

        private void OnManaUpdate(
            ManaUpdatePacket packet)
        {
            ClientManaManager.SetMana(packet.Mana);
        }

        public void SendResetMana()
        {
            _netSender.SendSingleData(
                OneShotServerPacketId.ResetMana,
                new ReliableEmptyData()
            );
        }

        public void SendDeathReport(
            ushort killerId)
        {
            _netSender.SendSingleData(
                OneShotServerPacketId.DeathReport,
                new DeathReportPacket(killerId)
            );
        }
    }
}